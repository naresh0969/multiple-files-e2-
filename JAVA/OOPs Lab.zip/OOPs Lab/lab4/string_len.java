/*6. Write an application that finds the length of a given string. */

package lab4;
import java.util.*;
public class string_len {
    public static void main(String args){
        Scanner scan=new Scanner(System.in);
        // String str="hyderabad";
        scan.close();

    }
}
