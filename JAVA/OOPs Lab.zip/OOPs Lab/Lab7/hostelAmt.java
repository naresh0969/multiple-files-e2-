/*6. Create an Interface StudentFee with method getAmount(),getFirstName(),getLastName(),
getAddress(), getContact(). Calculate the amount paid by the Hostler and NonHostler
student by implementing interface Student Fee*/
import java.util.*;
interface studentFee{
    void getAmount();
    void getFirstName();
    void getLastName();
    void getAddress();
    void getContact();
}
class Hostler implements studentFee{
    int amount;
    String fname;
    String lname;
    String add;
    int ph;
Hostler(int amount,String fname,String lname,String add,int ph){
this.amount=amount;
this.fname=fname;
this.lname=lname;
this.add=add;
this.ph=ph;
}
public void getAmount(){
    System.out.println("the amount of hostler is:"+amount);
}
    public void getFirstName(){
        System.out.println("tthe first name is:"+fname);
    }
    public void getLastName(){
    System.out.println("the last name is:+"+lname);
    }
    public void getAddress(){
  System.out.println("the address is:"+add);
    }
    public void getContact(){
    System.out.println("contact number is:+"+ph);
    }
}
class NonHostler implements studentFee{
        int amount;
        String fname;
        String lname;
        String add;
        int ph;
    NonHostler(int amount,String fname,String lname,String add,int ph){
    this.amount=amount;
    this.fname=fname;
    this.lname=lname;
    this.add=add;
    this.ph=ph;
    }
    public void getAmount(){
        System.out.println("the amount of nonhostler is:"+amount);
    }
        public void getFirstName(){
            System.out.println("tthe first name is:"+fname);
        }
        public void getLastName(){
        System.out.println("the last name is:+"+lname);
        }
        public void getAddress(){
      System.out.println("the address is:"+add);
        }
        public void getContact(){
        System.out.println("contact number is:+"+ph);
        }
}
class hostelAmt{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the details of hostel employee as follows only:");
        System.out.println("enter the amount,firstname,last name,address,phone number");
int a=sc.nextInt();
String f=sc.next();
String l=sc.next();
String ad=sc.next();
int p=sc.nextInt();
System.out.println("enter the details of non-hostel employee as follows only:");
System.out.println("enter the amount,firstname,last name,address,phone number");
int a2=sc.nextInt();
String f2=sc.next();
String l2=sc.next();
String ad2=sc.next();
int p2=sc.nextInt();
Hostler h=new Hostler(a,f,l,ad,p);
h.getAmount();
    h.getFirstName();
    h.getLastName();
    h.getAddress();
    h.getContact();
    NonHostler h2=new NonHostler(a2,f2,l2,ad2,p2);
h2.getAmount();
    h2.getFirstName();
    h2.getLastName();
    h2.getAddress();
    h2.getContact();
    System.out.println("the total amount paid bu hostler and non hostler is:"+(a+a2));    
    }
}
