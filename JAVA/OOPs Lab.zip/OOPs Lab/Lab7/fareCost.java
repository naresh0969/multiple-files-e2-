/*Create an Interface Fare with method getAmount() to get the amount paid for fare
of travelling. Calculate the fare paid by bus and train implementing interface Fare.*/

import java.util.Scanner;

interface fare{
   void getAmount();
}
class bus implements fare{
    int busc;
    bus(int busc){
        this.busc=busc;
    }
    public void getAmount(){
        System.out.println("the amount paid to the bus is:"+busc);
    }
}
class train implements fare{
    int trac;
    train(int trac){
        this.trac=trac;
    }
    public void getAmount(){
        System.out.println("the amount paid to the train is:"+trac);
    }
}

public class fareCost {
public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("enter the amount paid to the bus:");
    int b=sc.nextInt();
    System.out.println("enter the amiunt paid for the train");
    int t=sc.nextInt();
    bus a1=new bus(b);
    a1.getAmount();;
    train a2=new train(t);
    a2.getAmount();
    System.out.println("the fare total amount paid"+(b+t));
}
    
}