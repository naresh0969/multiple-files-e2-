
 /*. Create an abstract class Employee with methods getAmount() which displays the
amount paid to employee. Reuse this class to calculate the amount to be paid to
WeeklyEmployeed and HourlyEmployee according to no. of hours and total hours
for HourlyEmployee and no. of weeks and total weeks for WeeklyEmployee.*/
import java.util.*;
abstract class employee{
    abstract double getAmount();
}
class WeeklyEmployee extends employee{
    int h;
    int s;
    WeeklyEmployee(int h,int s){
        this.h=h;
        this.s=s;
    }
    double getAmount(){
        return h*s;
    }
}
class hourEmployee extends employee{
    int h;
    int s;
    hourEmployee(int h,int s){
        this.h=h;
        this.s=s;
    }
    double getAmount(){
        return h*s;
    }
}
class abstEmp{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("the detaails of hour emplyeee:");
        System.out.println("enter the number of hours");
        int a=sc.nextInt();
     System.out.println("enetr the amount per hour");
        int b=sc.nextInt();
    System.out.println("the details of weekly employee");
    System.out.println("enter the hour of week employee");
    int c=sc.nextInt();
     System.out.println("enter the weeks of employee");
     int d=sc.nextInt();
        WeeklyEmployee a1=new WeeklyEmployee(a,b);
        System.out.println("total salary of hour employee:"+a1.getAmount());
        hourEmployee a2=new hourEmployee(c, d);
        System.out.println("the total salary of weekemployeee is:"+a2.getAmount());
    }
}