/*Create an Interface Vehicle with method getColor(),getNumber(), getConsumption()
calculate the fuel consumed, name and color for TwoWheeler and Four Wheeler By
implementing interface Vehicle.*/
import java.util.*;
interface  Vehicle{
    void getColor();
    void getNumber();
    void getConsumption();
}
class TwoWheeler implements Vehicle{
    int fuelc;
    String name;
    int num;
    String color;
    TwoWheeler(int fuelc,String name,int num,String color){
        this.fuelc=fuelc;
        this.name=name;
        this.num=num;
        this.color=color;
    }
    public void getColor(){
        System.out.println("the color of two wheeler bike is:+"+color);
    }
    public void getNumber(){
        System.out.println("name of two wheeler bike is:"+name);
        System.out.println("number of two wheeler bike is:"+num);
    }
    public void getConsumption(){
     System.out.println("the fuel conssumed by two wheeler is :"+fuelc);
    }
}
class fourWheeler implements Vehicle{
    int fuelc;
    String name;
    int num;
    String color;
    fourWheeler(int fuelc,String name,int num,String color){
        this.fuelc=fuelc;
        this.name=name;
        this.num=num;
        this.color=color;
    }
    public void getColor(){
        System.out.println("the color of four wheeler bike is:+"+color);
    }
    public void getNumber(){
        System.out.println("name of four wheeler bike is:"+name);
        System.out.println("number of four wheeler bike is:"+num);
    }
    public void getConsumption(){
     System.out.println("the fuel conssumed by four wheeler is :"+fuelc);
    }
}
class interbike{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("enetr the details of two wheeler :::as follows");
        System.out.println("enter the color,name,number,fuel consumef");
        String c=sc.next();
        String n=sc.next();
        int num=sc.nextInt();
        int fu=sc.nextInt();
        System.out.println("enetr the details of four wheeler :::as follows");
        System.out.println("enter the color,name,number,fuel consumef");
        String c2=sc.next();
        String n2=sc.next();
        int num2=sc.nextInt();
        int fu2=sc.nextInt();
        TwoWheeler a1=new TwoWheeler(fu,n,num,c);
        a1.getColor();
        a1.getNumber();
        a1.getConsumption();
        fourWheeler a2=new fourWheeler(fu2,n2,num2,c2);
        a2.getColor();
        a2.getNumber();
        a2.getConsumption();


    }
}