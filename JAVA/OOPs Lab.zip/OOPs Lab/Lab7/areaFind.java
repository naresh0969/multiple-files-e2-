/*1. Create an abstract class Shape which calculate the area and volume of 2-d and 3-d
shapes with methods getArea() and getVolume(). Reuse this class to calculate the area
and volume of square ,circle ,cube and sphere.*/
import java.util.*;
import java.lang.Math;
abstract class shape{
    abstract double getarea();
   abstract double getvolume();
}
class square extends shape{
    int side;
square(int side){
this.side=side;
}
   public  double getarea(){
return (side*side);
    }
   public  double getvolume(){
        return 4*side;
    }
}
class circle extends shape{
    int radius;
     circle(int radius){
        this.radius=radius;
    }
    double getarea(){
        return(Math.PI*radius*radius);
    }
    double getvolume(){
        return(2*Math.PI*radius);
    }
}
class cube extends shape{
    int s;
    cube(int s){
        this.s=s;

    }
    double getarea(){
        return(s*s*s);
    }
    double getvolume(){
        return(6*s);
    }
}
class sphere extends shape{
    int radius;
    sphere(int radius){
        this.radius=radius;
    }
    double getarea(){
        return (4*3.14*radius*radius);
        
    }
    double getvolume(){
        return((4/3)*3.14*radius*radius*radius);
    }
}
class areaFind{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
System.out.println("enter the side of a square");
int si=sc.nextInt();
System.out.println("enter the radius of a circle");
int rad=sc.nextInt();
System.out.println("enetr the side of a cube");
int cub=sc.nextInt();
System.out.println("enter the side of a sphere");
int s=sc.nextInt();
square a1=new square(si);
System.out.println(a1.getarea());
System.out.println(a1.getvolume());
circle a2=new circle(rad);
System.out.println(a2.getarea());;
System.out.println(a2.getvolume());
cube a3=new cube(cub);
System.out.println(a3.getarea());
System.out.println(a3.getvolume());
sphere a4=new sphere(s);
System.out.println(a4.getarea());
System.out.println(a4.getvolume());
  }
}