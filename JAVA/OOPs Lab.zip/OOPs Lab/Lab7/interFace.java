/*Create an Interface payable with method getAmount ().Calculate the amount to be
paid to Invoice and Employee by implementing Interface*/

import java.util.Scanner;

interface payable{
void  getAmount();
}
class Employee implements payable{
    String name;
    String designation;
    double salary;
    double charge;
Employee(String name,String designation, double salary,double charge){
    this.name=name;
    this.designation=designation;
    this.salary=salary;
    this.charge=charge;
}
public void getAmount(){
    double invoice=salary+charge;
    System.out.println("total invoice amount is:"+invoice);
}
}
class interFace{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("enetre the name of employee");
        String n=sc.next();
        System.out.println("enter the designation of employee");
        String des=sc.next();
         System.out.println("enter the salry amount of employee ");
         double sal=sc.nextDouble();
        System.out.println(" enter the total charge of employee ");
        double ch=sc.nextDouble();
        Employee obj=new Employee(n, des, sal, ch);
        obj.getAmount();


        
    }
}