class add{
    void sum(){
        int a=10,b=20;
        System.out.println(a+b);
    }
    void sum(int a,float b){
        float c=a+b;
        System.out.println(c);
    }
    void sum(double a,double b){
        double c=a+b;
        System.out.println(c);
    }
}
class overLoad{
    public static void main(String args[]){
        add obj=new add();
        obj.sum();
        obj.sum(10,22.2);
        obj.sum(11.1,22.2);    }
}