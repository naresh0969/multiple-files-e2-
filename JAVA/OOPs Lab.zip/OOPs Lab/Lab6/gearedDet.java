import java.util.*;
import vechicleDet.*;
class getname extends twowheel{
String type;
 public getname(String type){
    this.type=type;
}
void display(){
    System.out.println("the type is:"+type);
}
}
class gettype extends twowheel{
String compname;
  public gettype(String compname){
    this.compname=compname;
}
void display(){
    System.out.println("company name is:"+compname);
}
}
class geared extends twowheel{
    int avg;
    geared(int avg){
        this.avg=avg;
    }
    void average(){
        System.out.println("the average gared is:"+avg);
    }

}
class nongeared extends twowheel{
    int navg;
nongeared(int navg){
        this.navg=navg;
    }
    void average(){
        System.out.println("the average gared is:"+navg);
    }

}
class gearedDet{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the name of twowheel type");
        String twotype=sc.next();
        System.out.println("enter the company name of two wheel");
        String twoc=sc.next();
        System.out.println("enter the cost of average geared type");
        int gear=sc.nextInt();
        System.out.println("enter the cost of average of non geared type");
        int ngear=sc.nextInt();
        getname a1=new getname(twotype);
        a1.display();
        gettype a2=new gettype(twoc);
        a2.display();
        geared a3=new geared(gear);
        a3.average();
        nongeared a4=new nongeared(ngear);
        a4.average();
    }
}