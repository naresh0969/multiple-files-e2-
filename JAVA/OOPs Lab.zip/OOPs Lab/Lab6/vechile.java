package vechicleDet;
  public class vechile{
    int vnum;
    int vins;
    String color;
    int consumption;
    public void vechile(int vnum,String color,int vins){
     this.vnum=vnum;
     this.color=color;
     this.vins=vins;
    } 
    void getconsumption(){

     System.out.println("the consumption is:"+consumption);
    }
 }
class twowheel extends vechile{
     int cost;
     int cost2;
   public void twowheel(int cost,int cost2 ){
         this.cost=cost;
         this.cost2=cost2;
     }
     void mentatance(){
         System.out.println("the maintance cost is:"+cost);
     }
     void averagemaintain(){
         System.out.println("the average maintance cost is:"+cost2);
 
     }
    }
 
 