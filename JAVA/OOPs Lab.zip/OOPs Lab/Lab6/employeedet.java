class employee{
    private String firstname;
    private String lastname;
    void setfirstName(String firstname ){
        this.firstname=firstname;
    }
    void setlastName(String lastname){
        this.lastname=lastname;
    }
    String getfirstName(){
        return firstname;
    }
    String getlastName(){
        return lastname;
    }
}
class contractEmployee extends employee{
    String deparment;
    String designation;
    int salary;
    contractEmployee(String deparment,String designation,int salary){
        this.deparment=deparment;
        this.designation=designation;
        this.salary=salary;
    }
    void display(employee obj){
        System.out.println(obj.getfirstName()+obj.getlastName()+deparment+" "+designation+" "+salary);
    }

}
class regularEmployee extends employee{
    String depatment;
    String designation;
    int salary;

    regularEmployee(String depatment,String designation,int salary){
   

        this.depatment=depatment;
        this.designation=designation;
        this.salary=salary;
    }
    void display(employee obj){
        System.out.println(obj.getfirstName()+obj.getlastName()+depatment+" "+designation+" "+salary);
    }

}

public class employeedet {

    public static void main(String[] args) {
        System.out.println("the deatails of contract employees are");
        contractEmployee a1=new contractEmployee("upsc","ias",200000);

        employee obj=new employee();
        obj.setfirstName("ram");
        obj.setlastName("singh");
        a1.display(obj);
        System.out.println("the details of the regular emplouee");
        obj.setfirstName("badavth");
        obj.setlastName("nagaraju");
        regularEmployee a2=new regularEmployee("it", "software developer", 150000);
         a2.display(obj);


    }
}
