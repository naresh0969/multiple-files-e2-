import java.util.*;
class circle{
    int radius;
    double findArea(){
        return 3.14*radius*radius;
    }
    double findPerimeter(){
        return 2*3.14*radius;
    }
}
class circleArea{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("entr the radius of a circle:");
        circle obj=new circle();
        obj.radius=sc.nextInt();
        System.out.println("area of a circle is:"+" "+obj.findArea());
        System.out.println("perimeter of a circle is:"+obj.findPerimeter());
        

    }
}