import java.util.*;
class addition{
    void add(int x,int y){
        System.out.println("the sum of two numbers is:");
        System.out.println(x+y);
    }
}

public class callValue {
    public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    addition obj=new addition();
    System.out.println("enter the two numbers");
    int a=sc.nextInt();
    int b=sc.nextInt();
    obj.add(a,b);
}
}
