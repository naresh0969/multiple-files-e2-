import java.util.Scanner;

class student{
    int id;
    String name;
    String branch;
    void student(){
    this.id=id;
    this.name=name;
    this.String=branch;
}
void display(){
    System.out.println(+id+" "+name+""+branch);
}
}
class styDet{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        student obj=new student();
        System.out.println("enter id name and branch");
        obj.id=sc.nextInt();
        obj.name=sc.next();
        obj.branch=sc.next();
        obj.display();

    }
}