/*Write a JAVA program for the following
a. Call by value
b. Call by object */
package Lab5;
import java.util.Scanner;

class Solution{
    
}
public class Calls {
    public static void main(String args[]){

    }
}
