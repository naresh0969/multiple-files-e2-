class student{
int id;
String name;
static String subject="oops";
void student(int id,String name){
    this.id=id;
    this.name=name;
}
void display(){
    System.out.println(id+" "+name+" "+subject);
}

}
class staticvrb{
    public static void main(String args[]){
        student obj[]=new student[2];
        obj[0]=new student(1,"ramsingh");
        obj[1]=new student(2,"nagaraju");
        obj[0].display();
        obj[1].display();
        }
}