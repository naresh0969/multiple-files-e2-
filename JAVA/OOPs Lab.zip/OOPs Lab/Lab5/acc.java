import java.util.*;
class account{
    double balance;
}
class accountDetails extends account{
    String accName;
    int accNum;
    int accBal;
    int debbal;
    String accAdd; 
    void credit( int accBal){
        this.accBal=accBal;
        System.out.println("the available balance is:");
        System.out.println(balance+accBal);
    } 
    void debit(int debbal){
        this.debbal=debbal;
        if(balance+accBal>debbal){
            System.out.println("debit is successfull and the remaing balance is:");
            System.out.println((balance+accBal)-debbal);
        } 
        else{
            System.out.println("low balance please check the bslance:");
        }
}
}
class acc{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        accountDetails obj=new accountDetails();
        System.out.println("entr main balance");
        obj.balance=sc.nextInt();
        obj.accName="ramsingh";
        obj.accNum=900797;
        System.out.println("entr the amount you want to credit:");

        obj.accBal=sc.nextInt();
        obj.accAdd="wgl";
        obj.credit(obj.accBal);
     System.out.println("entr the amount you want to debit:");
     obj.debbal=sc.nextInt();
        obj.debit(obj.debbal);

    }
}