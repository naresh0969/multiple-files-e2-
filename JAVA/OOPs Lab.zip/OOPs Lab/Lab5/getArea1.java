 import java.util.*;
 import java.lang.Math;

 class shape{
    public double getArea(){
        return 0;
    }
    }

class circle extends shape{
    private double radius;
    circle(double radius){
        this.radius=radius;
    }
    public double getArea(){
        return Math.PI*radius*radius;
    }
}
class rectangle extends shape{
    private double l;
    private double b;
    rectangle(double l,double b){
        this.l=l;
        this.b=b;
    }
    public double getArea(){
        return l*b;
    }
}
class getArea1{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the radius of a circle");
        double rad=sc.nextDouble();
        circle a=new circle(rad);
        System.out.println(a.getArea());
        System.out.println("enter the lenght and breadth of a rectangle");
        int len=sc.nextInt();
        int bred=sc.nextInt();
      rectangle b=new rectangle(len, bred);
        System.out.println(b.getArea());
    }
}