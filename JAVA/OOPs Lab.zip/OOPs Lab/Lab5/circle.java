/*2. Write an application that prompts the user for the radius of a circle and uses a
method called circleArea to calculate the area of the circle and uses a method
circlePerimeter to calculate the perimeter of the circle. */
package Lab5;
import java.util.Scanner;
class CircleP{
    double circleArea(double radius){
        double area=Math.PI*radius*radius;
        return area;
    }
    double circlePerimeter(double radius){
        double perimeter=2*Math.PI*radius;
        return perimeter;
    }
}
public class circle {
    public static void main(String args[]){
        Scanner scan=new Scanner(System.in);
        double radius;
        System.out.println("Enter Radius :");
        radius=scan.nextDouble();
        CircleP obj=new CircleP();
        System.out.printf("Circle Area :"+obj.circleArea(radius));
        System.out.printf("Circle Perimeter :"+obj.circlePerimeter(radius));

        scan.close();

    }
}
