class Wrap{
    public static voidd main(String args[]){
        
        integer intwrapper=new integer(44);
        int value=intwrapper.value();
        System.out.println(value);
    }
}
