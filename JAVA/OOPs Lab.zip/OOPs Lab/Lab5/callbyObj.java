import java.util.Scanner;

class student{
    int id;
    String name;
    student(int id,String name){
        this.id=id;
        this.name=name;
    }
    void display(student2 b){
        System.out.println(id+" "+name+" "+b.age);

    }
    }
class student2{
int age;
student2(int age){
    this.age=age;
}
}


public class callbyObj {
    
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        student a=new student(12, "ramsingh");
        student2 b=new student2(22);
        a.display(b);

    }
}
