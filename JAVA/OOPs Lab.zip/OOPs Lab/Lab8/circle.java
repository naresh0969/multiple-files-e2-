package org.shapes;
public class circle{
    public void c_area(int radius){
        System.out.println("area of a circle is:"+3.14*radius*radius);
    }
}