import inter.dog;
class inter5{
    public static void main(String args[]){
        dog a=new dog();
        a.makeSound();
        
}
}