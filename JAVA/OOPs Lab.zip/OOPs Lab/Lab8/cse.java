/*3. Write a Java program to create package called dept. Create four classes as CSE, ECE, ME
and CE add methods in each class which can display subject names of your respect year.
access this package classes from main class*/
package dept;
public class cse{
    public void subjects(String s1,String s2,String s3){
        System.out.println("the subjects of cse is:");
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);     
    }
} 