package calculator;

public class div4
{
public void div1(float a,float b)
{
System.out.println("division of "+a+" and "+b+" is:"+(a/b));
}
}