import org.shapes.square;
import org.shapes.triangl;
import org.shapes.circle;
class difshapes2 {
    public static void main(String[] args) {
        square a1=new square();
        triangl a12=new triangl();
        circle a3=new circle();
        a1.area(10);
        a12.triarea(10,20);
        a3.c_area(10);
    }

    
}