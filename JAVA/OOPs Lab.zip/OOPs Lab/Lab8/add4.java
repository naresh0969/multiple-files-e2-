/*4. Write a Calculator program : Include all calculator operations in as classes in a Package
“Calculator” and import in to main class.*/
package calculator;
public class add4
{
public void add1(float a,float b)
{
System.out.println("addition of "+a+ " and"+b+" is:"+(a+b));
}
}
