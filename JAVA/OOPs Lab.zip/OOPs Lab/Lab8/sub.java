package p2;
public class sub{
    public void displaysub(int x,int y){
        System.out.println(x-y);
    }
}