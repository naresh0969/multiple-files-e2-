import java.util.*;
import p1.add;
import p2.sub;
class pack1{
    public static void main(String args[]){
        add a1=new add();
        a1.displaysum(10,20);
        sub a2=new sub();
        a2.displaysub(20,10);
    }
}