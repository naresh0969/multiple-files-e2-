package calculator;

public class mul4
{
public void mul1(float a,float b)
{
System.out.println("multipcation of"+a+" and"+b+" is:"+(a*b));
}
}
