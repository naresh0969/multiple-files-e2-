/*1. Write a Program to create your own package. Package should have more than two classes.
write a Program that uses the classes from the package.*/
package p1;
public class add{
    public void displaysum(int a,int b){
        System.out.println(a+b);
    }
}