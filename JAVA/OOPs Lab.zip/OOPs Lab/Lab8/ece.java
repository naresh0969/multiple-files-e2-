package dept;
public class ece{
    public void ece_sub(String s1,String s2,String s3){
        System.out.println("the subjects of ece is:");
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);     
    }
} 