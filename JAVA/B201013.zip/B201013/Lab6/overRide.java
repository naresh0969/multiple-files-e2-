class animal{
    void display(){
        System.out.println("iam the sub class");
    }
}
class birds extends animal{
    void display(){
        System.out.println("method override");
    }
}
class overRide{
    public static void main(String args[]){
        birds obj=new birds();
        obj.display();
        animal o=new animal();
        o.display();

    }
}