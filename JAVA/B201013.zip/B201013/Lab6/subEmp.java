import java.util.*;
import conEmp.conEmployee;
class houremployee extends conEmployee{
    int hour;
    int amount;
    String designation;
houremployee(int hour,int amount,String designation){
    this.hour=hour;
    this.amount=amount;
    this.designation=designation; 
}
void display(){
    System.out.println("the desination of hour employee is:"+designation);
    System.out.println("total salary  per hour is:"+hour*amount);
    System.out.println("monthly salary of hour employee is:"+30*(hour*amount));
}

}
class weekemployee extends conEmployee{
    int week;
    int amount;
    String designation;
weekemployee(int week,int amount,String designation){
    this.week=week;
    this.amount=amount;
    this.designation=designation; 
}
void display(){
    System.out.println("the desination of week employee is:"+designation);
    System.out.println("total salary  per week is:"+week*amount);
    //System.out.println("monthly salary of week employee is:"+30*(week*amount));
}
}
class subEmp{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number of hour work for hour employess");
        int hr=sc.nextInt();
        System.out.println("enter the amount per hour for hour employee");
        int amt=sc.nextInt();
        System.out.println("enter the designation of hour employee");
        String des=sc.next();
        houremployee a=new houremployee(hr,amt,des);
        a.display();
        System.out.println("the details of week employee");
        System.out.println("enter the number of hours:");
        int h=sc.nextInt();
        System.out.println("enter amount per week");
        int am=sc.nextInt();
        System.out.println("enter the designation of week employee");
        String de=sc.next();
        weekemployee obj=new weekemployee(h,am,de);
        obj.display();




        
    }
}