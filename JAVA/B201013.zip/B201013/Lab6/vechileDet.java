import java.util.*;
class vechile{
   int vnum;
   int vins;
   String color;
   int consumption;
    void vechile(int vnum,String color,int vins){
    this.vnum=vnum;
    this.color=color;
    this.vins=vins;
   } 
   void getconsumption(){
    System.out.println("the consumption is:"+consumption);
   }
}
class twowheel extends vechile{
    int cost;
    int cost2;
 twowheel(int cost,int cost2 ){
        this.cost=cost;
        this.cost2=cost2;
    }
    void mentatance(){
        System.out.println("the maintance cost is:"+cost);
    }
    void averagemaintain(){
        System.out.println("the average maintance cost is:"+cost2);

    }

}
class fourwheel extends vechile{
    int c1;
    int c2;

    fourwheel(int c1,int c2 ){
        this.c1=c1;
        this.c2=c2;
    }
    void mentatance(){
        System.out.println("the maintance cost is:"+c1);
    }
    void averagemaintain(){
        System.out.println("the average maintance cost is:"+c2);

    }
}
class vechileDet{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("the details of twowhhel ::");
        System.out.println("enter the  vechile number");
        int num=sc.nextInt();
        System.out.println("enter the insurance number");
        int ins=sc.nextInt();
        System.out.println("enter the color");
        String col=sc.next();
        System.out.println("enter the maintaince cost of two wheel:");
        int mcost=sc.nextInt();
        System.out.println("enter the cost of four wheel:");
        int vcost=sc.nextInt();
        twowheel obj1=new twowheel(mcost,vcost);
        obj1.mentatance();
        obj1.averagemaintain();
        System.out.println("enter the details of four wheel vechicle"); 
        System.out.println("enter the  vechile number");
        int num2=sc.nextInt();
        System.out.println("enter the insurance number");
        int ins2=sc.nextInt();
        System.out.println("enter the color");
        String col2=sc.next();
        System.out.println("enter the maintaince cost of four wheel:");
        int mcost1=sc.nextInt();
        System.out.println("enter the cost of four wheel:");
        int vcost1=sc.nextInt();
        fourwheel obj2=new fourwheel(mcost1,vcost1);
        obj2.mentatance();
        obj2.averagemaintain();



    }
}