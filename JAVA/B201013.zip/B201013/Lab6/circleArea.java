import java.util.*;
class findArea{

    void display(){
        int radius=10;
        System.out.println("area of a circle is:"+3.14*radius*radius);
    }
    void display(int radius){
        System.out.println(3.14*radius*radius);
    }
    void display(float radius){
     System.out.println(3.14*radius*radius);
    }
    void display(double radius){
     System.out.println(3.14*radius*radius);

    }
}
class circleArea{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        findArea obj=new findArea();
        obj.display();
        System.out.println("enter the radius of acircle");
        int rad=sc.nextInt();
        obj.display(rad);
     System.out.println("enter the second radius of acircle");
     float rad2=sc.nextInt();
     obj.display(rad2);
     System.out.println("enter the third radius of acircle");
     double rad3=sc.nextInt();
     obj.display(rad3);

    }
}