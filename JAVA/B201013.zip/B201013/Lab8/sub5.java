/*Write a program for the following
a. Example to use interfaces in Packages.
b. Example to create sub package in a package.*/
import org.shapes.circle;
class sub5{
    public static void main(String args[]){
        circle obj=new circle();
        obj.c_area(20);
    }
}