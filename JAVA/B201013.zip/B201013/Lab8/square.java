/*2.Create a package named org.shapes. Create some classes in the package
representing some common geometric shapes like Square, Triangle, Circle and so
on. write a Program that uses the classes from the package.*/
package org.shapes;
public class square{
    public void area(int side){
System.out.println("the area of a square is:"+side*side);
    }

}