/*1. Write a Program to create your own package. Package should have more than two classes.
write a Program that uses the classes from the package*/
package Lab8;

public class OwnPackage {
    
}
