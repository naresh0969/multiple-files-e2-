package calculator;

public class sub4
{
public void sub1(float a,float b)
{
System.out.println("subtraction of "+a+" and"+b+" is:"+(a-b));
}
}