package dept;
public class me{
    public void me_sub(String s1,String s2,String s3){
        System.out.println("the subjects of cse is:");
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);     
    }
} 