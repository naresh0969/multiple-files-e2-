package org.shapes;
public class triangl{
    public void triarea(int base,int height){
        System.out.println("the area of traingle is:"+0.5*base*height);
    }
}