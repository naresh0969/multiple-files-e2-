// 3. Create an Interface payable with method getAmount ().Calculate the amount to be
// paid to Invoice and Employee by implementing Interface.

import java.util.*;
public interface payable{
    double getAmount();


}
class Invoice implements payable{
    private String Invoice_NO;
    private double Invoice_amount;
    public Invoice(String Invoice_NO,double Invoice_amount){
        this.Invoice_NO=Invoice_NO;
        this.Invoice_amount=Invoice_amount;

    }
    public double getAmount(){
        return Invoice_amount;
    }
}

 class Employee implements payable{
    private int Employee_ID;
    private double Employee_amount;
    public Employee(int Employee_ID,double Employee_amount){
        this.Employee_ID=Employee_ID;
        this. Employee_amount= Employee_amount;

    }
    public double getAmount(){
        return  Employee_amount;
    }
}
class test{
    public static void main(String args[]){
        Invoice voice=new Invoice("B201089",50000);
        System.out.println("the Invoice Amount:"+voice.getAmount());

        Employee emp=new Employee(189,34000);
        System.out.println("the Employee Amount:"+emp.getAmount());

    }
}