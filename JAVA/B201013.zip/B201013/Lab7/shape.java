// 1. Create an abstract class Shape which calculate the area and volume of 2-d and 3-d
// shapes with methods getArea() and getVolume(). Reuse this class to calculate the area
// and volume of square ,circle ,cube and sphere.

import java.util.*;
 abstract class Shape{
 public   abstract double getArea();
  public  abstract  double getVolume();
}
class square extends Shape{
    private double side;
    public square(double side){
        this.side=side;
    }
   public double getArea(){
        return side*side;
    }
    public double getVolume(){
        return 0;
    }
}
class circle extends Shape{
    private double radius;
    public circle(double radius){
        this.radius=radius;
    }
    public double getArea(){
        return Math.PI*radius*radius;
    }
       public double getVolume(){
        return 0;
    }
}
class cube extends Shape{
    public double side;
    public cube(double side){
        this.side=side;
    }
    public double getArea(){
        return  6*side;
    }
    public double getVolume(){
        return side*side*side;
    }
}
class sphere extends Shape{
    public double radius;
    public sphere(double radius){
        this.radius=radius;
    }
    public double getArea(){
        return 4*Math.PI*radius*radius*radius;
    }
    public double getVolume(){
        return (4/3)*Math.PI*radius*radius*radius;
    }
}
class test{
    public static void main(String args[]){
        square sq=new square(3);
        System.out.println("The area of the square:"+sq.getArea());
        System.out.println("The volume of the square:"+sq.getArea());


        circle cir=new circle(2);
         System.out.println("The area of the circle:"+cir.getArea());
        System.out.println("The volume of the cirlce:"+cir.getArea());

          cube cub=new cube(4);
         System.out.println("The area of the cube:"+cub.getArea());
        System.out.println("The volume of the cube:"+cub.getArea());


  sphere sph=new sphere(2);
         System.out.println("The area of the sphere:"+sph.getArea());
        System.out.println("The volume of the sphere:"+sph.getArea());


    }
}