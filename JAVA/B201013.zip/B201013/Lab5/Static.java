import java.util.*;

class Static
{
	int roll;
	String name;
	static String college="RGUKT";
	Static(int r,String n)
	{
		roll=r;
		name=n;
	}
	static void change()
	{
		college="MALLAREDDY";
	}
	void display()
	{
		System.out.println("--------Details of Student------");
		System.out.println("Name:"+name+"\nRoll no:"+roll+"\nCollege:"+college);
	}
	public static void main(String args[])
	{
		Static s1=new Static(52,"Varun");
		s1.display();
		change();//calling static method without object creation
		s1.display();
	}
}
		
		
