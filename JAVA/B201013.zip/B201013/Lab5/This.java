import java.util.*;


class This
{
	int id,marks;
	String name;
	This(int id,String name,int marks)
	{
		this.id=id;
		this.name=name;
		this.marks=marks;
		this.display();
	}
	void display()
	{
		System.out.println("Student details:");
		System.out.print("Name:"+name+"\n"+"Id:"+id+"\n"+"Marks:"+marks);
	}
	void show()
	{
		System.out.println("\nThis is show method");
	}
	public static void main(String args[])
	{	
		This s1=new This(10,"Vinay",100);
		s1.show();
		
	}
}
