import java.util.*;

public class Circle
{
	public double circleArea(double radius)
	{
		return Math.PI*radius*radius;
	}
	public double circlePerimeter(double radius)
	{
		return 2*Math.PI*radius;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		double radius;
		System.out.println("Enter radius of the Circle:");
		radius=sc.nextDouble();
		Circle c=new Circle();
		System.out.println("The Area of the Circle is:"+c.circleArea(radius));
		System.out.println("The Perimeter of the Circle is:"+c.circlePerimeter(radius)); 
	}
}
