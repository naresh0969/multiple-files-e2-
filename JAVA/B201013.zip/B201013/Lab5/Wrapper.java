import java.util.*;

class Wrapper
{	
	static void AutoBoxing()
	{
		System.out.println("----Autoboxing----");
		int a=10;
		Integer b=a;
		System.out.println("int to Integer="+b);
		
		float c=20.9f;
		Float d=c;
		System.out.println("float to Float="+d);
		
		long e=123456;
		Long f=e;
		System.out.println("long to Long="+f);
		
		short g=123;
		Short h=g;
		System.out.println("short to Short="+h);
		
		double i=20.9;
		Double j=i;
		System.out.println("double to Double="+j);
		
		char k='v';
		Character l=k;
		System.out.println("character to Character="+l);
		
		byte m=2;
		Byte n=m;
		System.out.println("byte to Byte="+n);
		
		boolean o=false;
		Boolean p=o;
		System.out.println("boolean to Boolean="+p);
	}
	
	static void UnBoxing()
	{
		System.out.println("----Unboxing----");
		Integer q=10;
		int r=q.intValue();
		System.out.println("Integer to int="+r);
		
		Float s=39.45f;
		float t=s.floatValue();
		System.out.println("Float to float="+t);
		
		Long u=778763543L;
		long v=u.longValue();
		System.out.println("Float to float="+v);
		
		Short w=87;
		short x=w.shortValue();
		System.out.println("Short to short="+x);
		
		Double z=778.79823;
		double a=z.doubleValue();
		System.out.println("Double to double="+a);
		
		Character b='w';
		char c=b.charValue();
		System.out.println("Character to char="+c);
		
		Byte d=46;
		byte e=d.byteValue();
		System.out.println("Byte to byte="+e);
		
		Boolean f=true;
		boolean g=f.booleanValue();
		System.out.println("Boolean to boolean="+f);	
	}
				
	public static void main(String args[])
	{
		AutoBoxing();
		UnBoxing();
	}
}
		
