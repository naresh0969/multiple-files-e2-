import java.util.*;

class Parent
{
	String name="\nIam Parent variable printed from child class through super key word";
	void display()
	{
		System.out.println("\nParent Class");
	}
}
class Child extends Parent
{
	String name="\nIam Child variable";
	void display()
	{
		System.out.println("Child class");
		System.out.println(super.name);
		
	}
	void show ()
	{
		display();
		super.display();
	}
}

class Super
{	
	public static void main(String args[])
	{
		Child obj=new Child();
		obj.show();
	}
}
