import java.util.*;

public class Account
{
	double balance;
	Account()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the initial balance in your account:");
		balance=sc.nextDouble();
	}
	
	public void credit(int amt)
	{
		balance+=amt;
	}
	public void debit(int amt)
	{
		if(amt>balance)
		{
			System.out.println("Debit amount exceeded account balance:");
		}
		else
		{
			balance-=amt;
		}
	}
	public void getBalance()
	{
		System.out.println("Total Balance in your account is:"+balance);
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String Acct_Name,Acct_Address;
		long Acct_acctno;
		
		System.out.println("Enter your Account Details:");
		System.out.println("Account Number:");
		Acct_acctno=sc.nextLong();
		sc.nextLine();
		
		System.out.println("Account Name:");
		Acct_Name=sc.nextLine();
		
		System.out.println("Account Address:");
		Acct_Address=sc.nextLine();
		
		Account acc=new Account();
		
		int amount;
		System.out.println("Enter the amount to credit :");
		amount=sc.nextInt();
		acc.credit(amount);
		
		System.out.println("Enter the amount to debit :");
		amount=sc.nextInt();
		acc.debit(amount);
		
		acc.getBalance();
	}
}
		
				
		
		

