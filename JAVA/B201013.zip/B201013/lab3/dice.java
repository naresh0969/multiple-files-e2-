/*4. Write a java program : rolling a pair of dices 10 times [ each attempt should be delayed
by 10000 ms ] and count number Successful attempts.
successful attempt : If the pair of Dice results in same values. */

package lab3;

public class dice {
    
}
