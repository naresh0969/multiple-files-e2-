package lab3;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class UniqueNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Set<Integer> uniqueNumbers = new HashSet<>();

        System.out.println("Enter 5 numbers between 10 and 100 inclusive:");

        for (int i = 0; i < 5; i++) {
            int number;
            do {
                System.out.print("Enter number " + (i + 1) + ": ");
                number = scanner.nextInt();

                // Check if number is within the specified range
                if (number < 10 || number > 100) {
                    System.out.println("Please enter a number between 10 and 100 inclusive.");
                } else if (uniqueNumbers.contains(number)) {
                    System.out.println("Duplicate number. Enter a different number.");
                } else {
                    uniqueNumbers.add(number);
                    break; // Break the loop if it's a valid and unique number
                }
            } while (true);

            // Display unique values after each new input
            System.out.print("Unique values input: ");
            for (int value : uniqueNumbers) {
                System.out.print(value + " ");
            }
            System.out.println();
        }

        scanner.close();
    }
}
